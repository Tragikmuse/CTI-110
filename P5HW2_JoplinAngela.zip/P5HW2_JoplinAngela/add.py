def add_nums(num1, num2):
    
    g = 0
    print('  ', num1)
    print('+ ', num2)
    print()
    user_answer = int(input('Enter your answer\n'))
    
    while user_answer != num1 + num2: 
       
        if user_answer < num1 + num2:
            print('Sorry, your guess is too low')
            g = g + 1
            print()
            user_answer = int(input('Try again\n'))
                               
        else:
            print('Sorry, your guess is too high')
            g = g + 1
            print()
            user_answer = int(input('Try again\n'))
           
    print('Congratulations!!!! You are correct!')
    g = g + 1
    print('Number of guesses: ', g)
    print()
