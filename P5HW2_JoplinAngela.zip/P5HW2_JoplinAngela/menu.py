def display_menu():
    print('MAIN MENU')
    print('********************************')
    print('1. Adding Random Numbers')
    print('2. Subtracting Random Numbers')
    print('3. Exit')
    print()
    
