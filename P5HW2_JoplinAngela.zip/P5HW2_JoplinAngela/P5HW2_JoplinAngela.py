# Menu driven simple math quizzes using functions, loops and modules
# 11/23/2022
# CTI-110 P5HW2 - Math Quiz
# Angela Joplin

# create functions for menu, adding, subtracting, save as modules and import
# modules for program.  Loop the functions 

import random
import menu
import add
import sub

print('Welcome to Math Quiz')
print()
print()


# Main
stop = False

while stop == False:
    menu.display_menu()

    user_selection = input('Please choose 1, 2, or 3: ')
    
    if user_selection == '1':
        add.add_nums(random.randint(1,100), random.randint(1,100))
    elif user_selection == '2':
        sub.sub_nums(random.randint(1,100), random.randint(1,100))
    elif user_selection == '3':
        stop = True
        print()
        print('Thank you for playing...')
        print('Goodbye!')
        
    else:
        print()
        print('That is not a valid selection!')
        print()


